package com.example.compareit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
